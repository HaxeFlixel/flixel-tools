![](https://raw.github.com/HaxeFlixel/haxeflixel.com/master/src/files/images/flixel-logos/flixel-tools.png)

[flixel](https://github.com/HaxeFlixel/flixel) | [addons](https://github.com/HaxeFlixel/flixel-addons) | [ui](https://github.com/HaxeFlixel/flixel-ui) | [demos](https://github.com/HaxeFlixel/flixel-demos) | [tools](https://github.com/HaxeFlixel/flixel-tools) | [templates](https://github.com/HaxeFlixel/flixel-templates) | [docs](https://github.com/HaxeFlixel/flixel-docs) | [haxeflixel.com](https://github.com/HaxeFlixel/haxeflixel.com)

[![Haxelib Version](https://img.shields.io/github/tag/HaxeFlixel/flixel-tools.svg?style=flat&label=haxelib)](http://lib.haxe.org/p/flixel-tools)
[![Build Status](https://travis-ci.org/HaxeFlixel/flixel-tools.png)](https://travis-ci.org/HaxeFlixel/flixel-tools)

##About

These are command line tools for HaxeFlixel to create demos, templates and more.

For documentation on how to install and use the tools, please refer to [this guide](http://haxeflixel.com/documentation/flixel-tools/).
