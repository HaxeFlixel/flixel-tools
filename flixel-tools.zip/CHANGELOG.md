v1.0.1
------------------------------
* Convert command: Fix FlxG.keys. conversion
* Setup command: Bugfix for entering a name with special chars
* build.bat added
* Compatibilty with latest version of flixel-templates (with "pregenerated" folder)
* Disabled the download command with flixel-demos and flixel-templates being on haxelib

v1.0.0
------------------------------
* Initial haxelib release
